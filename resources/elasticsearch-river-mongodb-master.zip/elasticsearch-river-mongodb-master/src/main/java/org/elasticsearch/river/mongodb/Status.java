package org.elasticsearch.river.mongodb;

public enum Status {

    UNKNOWN, START_FAILED, RUNNING, STOPPED, IMPORT_FAILED, INITIAL_IMPORT_FAILED, SCRIPT_IMPORT_FAILED, RIVER_STALE;

}
