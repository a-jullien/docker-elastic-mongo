var status = rs.status()
 for (i=0; i < status.members.length; i++) {
   if (status.members[i].state == 1) {
     db = connect(status.members[i].name + "/local")
   }
 }

use maindb
var o =
{
	"firstName": "John",
	"lastName": "Doe",
	"age": 34,
	"title_from_mongo": "Developer"
}

db.venue.save(o)