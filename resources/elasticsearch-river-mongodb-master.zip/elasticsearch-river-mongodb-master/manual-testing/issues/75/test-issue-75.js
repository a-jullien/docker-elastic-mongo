use mydb75
var o =
{
	"firstName": "John",
	"lastName": "Doe",
	"nickName": "The Boss",
	"creationDate": "2013-06-11T12:00:00.0000-04:00"
}

db.document.save(o)