db.mycollection95.save({
  "title": "中华料理 Chinese Cuisine",
  "tags": ["中国", "食物", "Chinese", "food"],
  "content": "中国菜很好吃。"
});