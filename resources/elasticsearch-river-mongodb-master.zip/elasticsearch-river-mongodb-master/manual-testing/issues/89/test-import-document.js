use mydb89
var o =
{
	"firstName": "John",
	"lastName": "Doe",
	"created": new Date(),
	"customerId": new BinData(3, "8Fq3Wd+BGUGD2CbsA4wasg==")
}

db.mycollec89.save(o)